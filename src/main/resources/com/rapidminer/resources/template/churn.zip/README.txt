2013.10.19  David Weisman

Here's an initial churn template.

Like the Direct Marketing demo, so that users don't need to check /Run template on the full data set/, I generated a dataset with 200 rows and tuned the decision tree to work well with that size.  Unfortunately 200 rows is a little small, and some of the DT parameters are a little sensitive to the randomness.  Obviously that's not a customer issue for our static demo dataset, but we may want to increase the full dataset threshold to gain some stability.

I developed this template on a small laptop (ThinkPad X series), and the two column format of the results panel is not ideal in this setting.  

- The scatter plot relates the top two attributes to churn prediction, which is a nice visualization for beginners.  This works with the demo data but the attribute names are specific to that data set, and will not work with arbitrary customer attributes.  

Based on the macro idea from /renderer_name=Text/, I tried dynamically setting macros for the scatter plot x and y parameters, and later referencing the macros in the result properties file:
   scatter_axis_x_axis=%{scatter_x}

Unfortunately that didn't work.  I validated that the macros are being set correctly, so the issue seems to be evaling the macro values.

For the moment I'm leaving the scatter plot in the template; we can later decide how to handle this issue, or just delete the plot.  The x and y macros are set inside 
/Compute attribute importance/.

I'm sure you can find a much better jpg for illustrating churn.

Comments and suggestions are always welcome.

Best regards,
Dave


